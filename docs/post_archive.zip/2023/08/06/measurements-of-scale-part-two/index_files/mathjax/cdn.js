var script = document.createElement("script");
script.type = "text/javascript";
script.src  = "https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_SVG";
document.getElementsByTagName("head")[0].appendChild(script);
